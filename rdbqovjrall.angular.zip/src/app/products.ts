export const products = [
  {
    name: 'Soporte tarda mucho',
    priority: 799
  },
  {
    name: 'El cliente no responde',
    priority: 699
  },
  {
    name: 'La gente a la que quiero preguntar algo desaparece',
    priority: 40
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/